import get from './get.js'
import stream from './stream.js'

export * from './types.js'

export default {
  get,
  stream
}
