import { Subject } from 'rxjs'

export const loggedIn$ = new Subject<boolean>()
