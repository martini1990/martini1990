declare module '@myetherwallet/mewconnect-web-client'
