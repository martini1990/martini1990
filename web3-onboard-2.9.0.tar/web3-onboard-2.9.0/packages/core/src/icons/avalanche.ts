export default `
  <svg width="100%" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M19.8682 0.489349H0.110352V18.4468H19.8682V0.489349Z" fill="white"/>
  </svg>
`
