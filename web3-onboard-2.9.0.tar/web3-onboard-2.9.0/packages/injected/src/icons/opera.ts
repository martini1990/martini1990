export default `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg width="100%" height="100%" viewBox="0 0 256 256" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid">
    <defs>
        <linearGradient x1="50.0025785%" y1="1.63039062%" x2="50.0025785%" y2="98.5448437%" id="linearGradient-1">
            <stop stop-color="#FF1B2D" offset="30%"></stop>
            <stop stop-color="#FA1A2C" offset="43.81%"></stop>
            <stop stop-color="#ED1528" offset="59.39%"></stop>
            <stop stop-color="#D60E21" offset="75.81%"></stop>
            <stop stop-color="#B70519" offset="92.72%"></stop>
            <stop stop-color="#A70014" offset="100%"></stop>
        </linearGradient>
        <linearGradient x1="49.9902998%" y1="0.852967626%" x2="49.9902998%" y2="99.5189748%" id="linearGradient-2">
            <stop stop-color="#9C0000" offset="0%"></stop>
            <stop stop-color="#FF4B4B" offset="70%"></stop>
        </linearGradient>
    </defs>
	<g>
		<path d="M85.9,200.1 C71.7,183.4 62.6,158.7 62,131 L62,125 C62.6,97.3 71.8,72.6 85.9,55.9 C104.3,32.1 131.3,21.4 161.8,21.4 C180.6,21.4 198.3,22.7 213.3,32.7 C190.8,12.4 161.1,0.1 128.5,0 L128,0 C57.3,0 0,57.3 0,128 C0,196.6 54,252.7 121.9,255.9 C123.9,256 126,256 128,256 C160.8,256 190.7,243.7 213.3,223.4 C198.3,233.4 181.6,233.8 162.8,233.8 C132.4,233.9 104.2,224 85.9,200.1 L85.9,200.1 Z" fill="url(#linearGradient-1)"></path>
		<path d="M85.9,55.9 C97.6,42 112.8,33.7 129.4,33.7 C166.7,33.7 196.9,75.9 196.9,128.1 C196.9,180.3 166.7,222.5 129.4,222.5 C112.8,222.5 97.7,214.1 85.9,200.3 C104.3,224.1 131.6,239.3 162,239.3 C180.7,239.3 198.3,233.6 213.3,223.6 C239.5,200 256,165.9 256,128 C256,90.1 239.5,56 213.3,32.6 C198.3,22.6 180.8,16.9 162,16.9 C131.5,16.9 104.2,32 85.9,55.9 L85.9,55.9 Z" fill="url(#linearGradient-2)"></path>
	</g>
</svg>`
