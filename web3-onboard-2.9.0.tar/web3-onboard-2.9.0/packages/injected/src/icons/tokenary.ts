export default `
  <?xml version="1.0" standalone="no"?>
  <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN"
  "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
  <svg version="1.0" xmlns="http://www.w3.org/2000/svg"
  width="256.000000pt" height="256.000000pt" viewBox="0 0 256.000000 256.000000"
  preserveAspectRatio="xMidYMid meet">
    <g transform="translate(0.000000,256.000000) scale(0.100000,-0.100000)"
    fill="#2C7CF5" stroke="none">
      <path d="M1120 1915 c-211 -57 -380 -213 -458 -423 -33 -90 -42 -266 -18 -362
      54 -216 210 -388 424 -468 90 -33 266 -42 362 -18 216 54 388 210 468 424 33
      90 42 266 18 362 -54 216 -210 388 -424 468 -85 32 -283 41 -372 17z"/>
    </g>
  </svg>
  `
