export default `<svg xmlns="http://www.w3.org/2000/svg" id="dcent-_171_4" width="100%" height="100%" viewBox="0 0 48 48">
<svg version="1.1" id="dcent-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 62.27 71.11" style="enable-background:new 0 0 62.27 71.11;" xml:space="preserve">
<style type="text/css">
	.dcent-st0{fill:#B3B5B5;}
	.dcent-st1{fill:#72BFBC;}
	.dcent-st2{fill:#6D6E70;}
</style>
<g>
	<polygon class="dcent-st0" points="32.04,13.43 37.34,10.37 37.34,3.06 32.04,0 32.04,0 	"/>
	<path class="dcent-st1" d="M12.53,45.25V24.69l17.71-10.22V0L0.9,16.94C0.34,17.26,0,17.86,0,18.5v33.88c0,0.03,0.01,0.07,0.01,0.1
		L12.53,45.25z"/>
	<path class="dcent-st2" d="M48.86,46.69L31.14,56.93L13.52,46.75L0.99,53.99l29.25,16.89c0.28,0.16,0.59,0.24,0.9,0.24
		c0.31,0,0.62-0.08,0.9-0.24l29.34-16.94c0.01,0,0.01-0.01,0.02-0.01L48.86,46.69z"/>
	<g>
		<path class="dcent-st0" d="M61.38,16.94l-11.63-6.71v7.3l-12.5,7.22l12.5,7.21v13.16l12.53,7.23V18.5
			C62.27,17.86,61.93,17.26,61.38,16.94z"/>
	</g>
	<polygon class="dcent-st2" points="24.93,31.85 24.94,46.18 37.1,39.16 37.1,24.83 	"/>
</g>
</svg>
`
