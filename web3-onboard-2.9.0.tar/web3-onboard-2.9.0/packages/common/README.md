# @web3-onboard/common

## A collection of functions and types that are shared across various packages in the Onboard V2 monorepo
